package br.com.programacao.portifolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortifolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
